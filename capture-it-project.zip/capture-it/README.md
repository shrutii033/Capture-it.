# Capture it.

A retro-inspired browser photo booth built with HTML, CSS and vanilla JavaScript.

## Run locally
1. Open this folder in VS Code.
2. Start a local server (for example, the Live Server extension), or run `python -m http.server 8000` from this folder.
3. Visit `http://localhost:8000`.
4. Allow camera access when prompted.

Camera access requires localhost or HTTPS. Photos are processed in the browser and are not uploaded to a server.

## Features
- Webcam capture with a 3-second countdown
- Retake or keep each photo
- Warm Film, Black & White, Faded Retro and Sepia filters
- One, three or four photo sessions
- Polaroid, vertical strip and grid compositions where compatible
- Burgundy, film-negative and black frames
- Optional caption
- PNG export

## Notes
Google Fonts are loaded online for the scrapbook/pixel typography. If offline, fallback fonts are used.
