(() => {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];

  const screens = {
    home: $("#homeScreen"),
    setup: $("#setupScreen"),
    camera: $("#cameraScreen"),
    edit: $("#editScreen")
  };

  const state = {
    filter: "warm",
    count: 4,
    frame: "burgundy",
    layout: "strip4",
    photos: [],
    currentPhoto: null,
    currentIndex: 0,
    stream: null,
    countdownTimer: null,
    busy: false
  };

  const video = $("#cameraVideo");
  const canvas = $("#previewCanvas");
  const ctx = canvas.getContext("2d");
  const filterOptions = $$(".filter-option");
  const countOptions = $$(".count-option");
  const frameOptions = $$(".frame-option");

  const FILTERS = {
    warm: "sepia(0.18) saturate(1.2) contrast(1.04)",
    bw: "grayscale(1) contrast(1.08)",
    faded: "saturate(.68) sepia(.12) brightness(1.06) contrast(.88)",
    sepia: "sepia(.72) saturate(.78) contrast(.96)"
  };

  function showScreen(name) {
    Object.entries(screens).forEach(([key, el]) => el.classList.toggle("hidden", key !== name));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function stopCamera() {
    if (state.stream) {
      state.stream.getTracks().forEach(track => track.stop());
      state.stream = null;
    }
    video.srcObject = null;
    video.style.display = "none";
  }

  function clearCountdown() {
    if (state.countdownTimer) {
      clearInterval(state.countdownTimer);
      state.countdownTimer = null;
    }
    $("#countdown").classList.add("hidden");
    state.busy = false;
  }

  function resetSession() {
    clearCountdown();
    stopCamera();
    state.photos = [];
    state.currentPhoto = null;
    state.currentIndex = 0;
    state.busy = false;
    $("#captionInput").value = "";
    $("#captionCount").textContent = "0 / 40";
    $("#downloadStatus").textContent = "";
    $("#cameraError").classList.add("hidden");
    updateProgress();
  }

  function setFilter(filter) {
    state.filter = filter;
    filterOptions.forEach(button => button.classList.toggle("selected", button.dataset.filter === filter));
  }

  function setCount(count) {
    state.count = Number(count);
    countOptions.forEach(button => button.classList.toggle("selected", Number(button.dataset.count) === state.count));
  }

  function setFrame(frame) {
    state.frame = frame;
    frameOptions.forEach(button => button.classList.toggle("selected", button.dataset.frame === frame));
    renderPreview();
  }

  function availableLayouts() {
    if (state.photos.length === 1) return [{ id: "polaroid", name: "Single Polaroid", icon: "single" }];
    if (state.photos.length === 3) return [{ id: "strip3", name: "3-photo vertical strip", icon: "strip" }];
    return [
      { id: "strip4", name: "4-photo vertical strip", icon: "strip" },
      { id: "grid4", name: "4-photo grid", icon: "grid" }
    ];
  }

  function renderLayoutOptions() {
    const holder = $("#layoutOptions");
    holder.innerHTML = "";
    const layouts = availableLayouts();
    if (!layouts.some(layout => layout.id === state.layout)) state.layout = layouts[0].id;
    layouts.forEach(layout => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `layout-option ${state.layout === layout.id ? "selected" : ""}`;
      button.dataset.layout = layout.id;
      const icon = document.createElement("span");
      icon.className = `layout-icon ${layout.icon === "grid" ? "grid-icon" : ""}`;
      const parts = layout.icon === "grid" ? 4 : (layout.icon === "single" ? 1 : 3);
      for (let i = 0; i < parts; i++) icon.appendChild(document.createElement("span"));
      const label = document.createElement("b");
      label.textContent = layout.name;
      button.append(icon, label);
      button.addEventListener("click", () => {
        state.layout = layout.id;
        renderLayoutOptions();
        renderPreview();
      });
      holder.appendChild(button);
    });
  }

  function updateProgress() {
    $("#photoProgress").textContent = `PHOTO ${Math.min(state.currentIndex + 1, state.count)} OF ${state.count}`;
    const strip = $("#progressStrip");
    strip.innerHTML = "";
    for (let i = 0; i < state.count; i++) {
      const frame = document.createElement("div");
      frame.className = `progress-frame ${state.photos[i] ? "filled" : "empty-frame"}`;
      if (state.photos[i]) {
        const img = document.createElement("img");
        img.src = state.photos[i];
        img.alt = `Captured photo ${i + 1}`;
        frame.appendChild(img);
      } else {
        frame.textContent = String(i + 1).padStart(2, "0");
      }
      strip.appendChild(frame);
    }
  }

  async function startCamera() {
    $("#cameraError").classList.add("hidden");
    $("#cameraPlaceholder").classList.remove("hidden");
    $("#cameraStatus").textContent = "CONNECTING...";
    $("#captureButton").classList.remove("hidden");
    $("#retakeButton").classList.add("hidden");
    $("#continueButton").classList.add("hidden");
    try {
      stopCamera();
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Your browser does not support camera access. Try a recent version of Chrome, Edge, Firefox or Safari.");
      }
      state.stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 960 } }
      });
      video.srcObject = state.stream;
      video.style.display = "block";
      await video.play();
      $("#cameraPlaceholder").classList.add("hidden");
      $("#cameraStatus").textContent = "CAMERA READY";
      $("#cameraHint").textContent = "A three-second countdown will start before each photo.";
      updateProgress();
    } catch (error) {
      stopCamera();
      $("#cameraStatus").textContent = "CAMERA NOT READY";
      let message = "We couldn't open your camera. Check your browser permissions and try again.";
      if (error.name === "NotAllowedError" || error.name === "PermissionDeniedError") {
        message = "Camera permission was blocked. Allow camera access in your browser's address-bar settings, then try again.";
      } else if (error.name === "NotFoundError" || error.name === "DevicesNotFoundError") {
        message = "No camera was found. Connect a camera and try again.";
      } else if (error.name === "NotReadableError" || error.name === "TrackStartError") {
        message = "Your camera may be in use by another app. Close that app and try again.";
      } else if (error.message) {
        message = error.message;
      }
      showCameraError(message);
    }
  }

  function showCameraError(message) {
    const box = $("#cameraError");
    box.innerHTML = "";
    const text = document.createElement("span");
    text.textContent = message + " ";
    const retry = document.createElement("button");
    retry.type = "button";
    retry.className = "text-button";
    retry.textContent = "RETRY CAMERA";
    retry.addEventListener("click", startCamera);
    box.append(text, retry);
    box.classList.remove("hidden");
  }

  function captureRawPhoto() {
    if (!video.videoWidth || !video.videoHeight) throw new Error("The camera is still starting. Please wait a moment and try again.");
    const capture = document.createElement("canvas");
    capture.width = video.videoWidth;
    capture.height = video.videoHeight;
    const c = capture.getContext("2d");
    // The preview is mirrored; mirror the saved photo too so it matches what the user saw.
    c.translate(capture.width, 0);
    c.scale(-1, 1);
    c.drawImage(video, 0, 0, capture.width, capture.height);
    return capture.toDataURL("image/jpeg", 0.94);
  }

  function startCountdown() {
    if (state.busy || !state.stream) return;
    state.busy = true;
    $("#captureButton").disabled = true;
    $("#cameraHint").textContent = "Get ready...";
    const counter = $("#countdown");
    let remaining = 3;
    counter.textContent = remaining;
    counter.classList.remove("hidden");
    state.countdownTimer = setInterval(() => {
      remaining -= 1;
      if (remaining > 0) {
        counter.textContent = remaining;
      } else {
        clearCountdown();
        counter.classList.add("hidden");
        try {
          state.currentPhoto = captureRawPhoto();
          $("#flashOverlay").classList.remove("flash");
          void $("#flashOverlay").offsetWidth;
          $("#flashOverlay").classList.add("flash");
          showCapturedPhoto();
        } catch (error) {
          $("#cameraHint").textContent = error.message;
          $("#captureButton").disabled = false;
        }
      }
    }, 1000);
  }

  function showCapturedPhoto() {
    video.style.display = "none";
    $("#cameraPlaceholder").classList.add("hidden");
    const old = $("#capturedPreview");
    if (old) old.remove();
    const image = document.createElement("img");
    image.id = "capturedPreview";
    image.alt = "Your captured photo preview";
    image.src = state.currentPhoto;
    image.style.cssText = `position:absolute;inset:0;width:100%;height:100%;object-fit:cover;filter:${FILTERS[state.filter]}`;
    $("#videoWrap").appendChild(image);
    $("#captureButton").classList.add("hidden");
    $("#retakeButton").classList.remove("hidden");
    $("#continueButton").classList.remove("hidden");
    $("#cameraHint").textContent = "Like it? Keep it. Want another? Retake.";
    $("#cameraStatus").textContent = "PHOTO PREVIEW";
    $("#retakeButton").disabled = false;
    $("#continueButton").disabled = false;
  }

  function returnToLive() {
    const image = $("#capturedPreview");
    if (image) image.remove();
    video.style.display = "block";
    $("#captureButton").classList.remove("hidden");
    $("#captureButton").disabled = false;
    $("#retakeButton").classList.add("hidden");
    $("#continueButton").classList.add("hidden");
    $("#cameraStatus").textContent = "CAMERA READY";
    $("#cameraHint").textContent = "A three-second countdown will start before each photo.";
  }

  function retakePhoto() {
    state.currentPhoto = null;
    returnToLive();
  }

  function continuePhoto() {
    if (!state.currentPhoto) return;
    state.photos[state.currentIndex] = state.currentPhoto;
    state.currentPhoto = null;
    state.currentIndex += 1;
    updateProgress();
    if (state.currentIndex >= state.count) {
      stopCamera();
      const image = $("#capturedPreview");
      if (image) image.remove();
      renderLayoutOptions();
      renderPreview();
      showScreen("edit");
    } else {
      returnToLive();
      updateProgress();
    }
  }

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("A captured photo could not be loaded."));
      image.src = src;
    });
  }

  function drawCover(context, image, x, y, width, height, filter) {
    const imageRatio = image.width / image.height;
    const boxRatio = width / height;
    let sx = 0, sy = 0, sw = image.width, sh = image.height;
    if (imageRatio > boxRatio) {
      sw = image.height * boxRatio;
      sx = (image.width - sw) / 2;
    } else {
      sh = image.width / boxRatio;
      sy = (image.height - sh) / 2;
    }
    context.save();
    context.filter = filter || "none";
    context.drawImage(image, sx, sy, sw, sh, x, y, width, height);
    context.restore();
  }

  function roundedRect(context, x, y, w, h, r) {
    context.beginPath();
    context.roundRect(x, y, w, h, r);
  }

  async function renderPreview() {
    if (!state.photos.length) return;
    try {
      const images = await Promise.all(state.photos.map(loadImage));
      const W = 900;
      const isPolaroid = state.layout === "polaroid";
      const isGrid = state.layout === "grid4";
      const count = images.length;
      const H = isPolaroid ? 1080 : (isGrid ? 980 : 1500);
      canvas.width = W;
      canvas.height = H;
      ctx.clearRect(0, 0, W, H);

      // Outer paper background
      ctx.fillStyle = "#f8eee3";
      ctx.fillRect(0, 0, W, H);

      const frameColor = state.frame === "burgundy" ? "#400106" : (state.frame === "black" ? "#171512" : "#201b17");
      const margin = isPolaroid ? 105 : 105;
      const gap = isGrid ? 22 : 18;
      let boxes = [];

      if (isPolaroid) {
        boxes = [{ x: 155, y: 105, w: 590, h: 700 }];
      } else if (isGrid) {
        const size = 330;
        boxes = [
          { x: 105, y: 125, w: size, h: size },
          { x: 465, y: 125, w: size, h: size },
          { x: 105, y: 485, w: size, h: size },
          { x: 465, y: 485, w: size, h: size }
        ];
      } else {
        const usableW = 610;
        const photoH = state.layout === "strip3" ? 365 : 290;
        const totalH = count * photoH + (count - 1) * gap;
        const startY = Math.max(65, (H - totalH - 190) / 2);
        for (let i = 0; i < count; i++) boxes.push({ x: 145, y: startY + i * (photoH + gap), w: usableW, h: photoH });
      }

      // Frame backing
      const outer = isPolaroid
        ? { x: 125, y: 75, w: 650, h: 870 }
        : isGrid
          ? { x: 75, y: 95, w: 750, h: 790 }
          : { x: 105, y: 35, w: 690, h: H - 120 };
      ctx.fillStyle = frameColor;
      ctx.fillRect(outer.x, outer.y, outer.w, outer.h);

      if (state.frame === "film") {
        // Film negative perforations on both sides
        ctx.fillStyle = "#f8eee3";
        const holeSize = 16;
        for (let y = outer.y + 18; y < outer.y + outer.h - 12; y += 34) {
          ctx.fillRect(outer.x + 9, y, holeSize, 12);
          ctx.fillRect(outer.x + outer.w - holeSize - 9, y, holeSize, 12);
        }
      }

      boxes.forEach((box, index) => {
        const border = state.frame === "film" ? 35 : 22;
        ctx.fillStyle = "#fffaf3";
        ctx.fillRect(box.x - border, box.y - border, box.w + border * 2, box.h + border * 2);
        drawCover(ctx, images[index], box.x, box.y, box.w, box.h, FILTERS[state.filter]);
      });

      // Polaroid's characteristic lower margin
      if (isPolaroid) {
        ctx.fillStyle = "#fffaf3";
        ctx.fillRect(177, 827, 546, 85);
      }

      const caption = $("#captionInput").value.trim();
      if (caption) {
        ctx.save();
        ctx.fillStyle = state.frame === "black" ? "#fff8ed" : (state.frame === "film" ? "#fff8ed" : "#400106");
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.font = "600 42px Caveat, cursive";
        const maxWidth = outer.w - 100;
        ctx.fillText(caption, W / 2, outer.y + outer.h - (isPolaroid ? 42 : 48), maxWidth);
        ctx.restore();
      }

      // Tiny hand-drawn style footer mark
      ctx.save();
      ctx.fillStyle = state.frame === "black" ? "#fff8ed" : "#d9b991";
      ctx.textAlign = "center";
      ctx.font = "22px Georgia, serif";
      ctx.fillText("✳", W / 2, H - 38);
      ctx.restore();
    } catch (error) {
      $("#downloadStatus").textContent = "Couldn't create the preview. Please retake your photos.";
      console.error(error);
    }
  }

  function downloadComposition() {
    if (!state.photos.length) return;
    renderPreview().then(() => {
      try {
        canvas.toBlob(blob => {
          if (!blob) {
            $("#downloadStatus").textContent = "The image could not be exported. Please try again.";
            return;
          }
          const url = URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.href = url;
          link.download = "capture-it-photo.png";
          document.body.appendChild(link);
          link.click();
          link.remove();
          setTimeout(() => URL.revokeObjectURL(url), 1500);
          $("#downloadStatus").textContent = "Your photo is ready. Check your downloads! ♡";
        }, "image/png");
      } catch (error) {
        $("#downloadStatus").textContent = "Download failed. Please try again.";
        console.error(error);
      }
    });
  }

  // Navigation
  $("#startButton").addEventListener("click", () => showScreen("setup"));
  $("#homeLink").addEventListener("click", event => { event.preventDefault(); resetSession(); showScreen("home"); });
  $$("[data-go]").forEach(button => button.addEventListener("click", () => {
    const destination = button.dataset.go;
    if (destination === "home") { resetSession(); showScreen("home"); }
    if (destination === "setup") { stopCamera(); showScreen("setup"); }
    if (destination === "camera") { showScreen("camera"); startCamera(); }
  }));

  filterOptions.forEach(button => button.addEventListener("click", () => setFilter(button.dataset.filter)));
  countOptions.forEach(button => button.addEventListener("click", () => setCount(button.dataset.count)));
  frameOptions.forEach(button => button.addEventListener("click", () => setFrame(button.dataset.frame)));

  $("#openCameraButton").addEventListener("click", async () => {
    resetSession();
    showScreen("camera");
    await startCamera();
  });
  $("#captureButton").addEventListener("click", startCountdown);
  $("#retakeButton").addEventListener("click", retakePhoto);
  $("#continueButton").addEventListener("click", continuePhoto);
  $("#captionInput").addEventListener("input", () => {
    $("#captionCount").textContent = `${$("#captionInput").value.length} / 40`;
    renderPreview();
  });
  $("#downloadButton").addEventListener("click", downloadComposition);
  $("#retakeAllButton").addEventListener("click", () => {
    if (window.confirm("Start over? Your captured photos and caption will be cleared.")) {
      resetSession();
      showScreen("setup");
    }
  });

  window.addEventListener("pagehide", stopCamera);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden && state.stream) stopCamera();
  });

  // Initial defaults
  setFilter("warm");
  setCount(4);
  setFrame("burgundy");
})();